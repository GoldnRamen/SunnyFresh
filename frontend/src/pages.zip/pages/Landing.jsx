import React from "react";
import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { FaEye, FaBars, FaTimes } from "react-icons/fa";
import logo from "../PNG/household.png"
import central from "../PNG/laundry-room.png"
import { TbCurrencyNaira } from "react-icons/tb";
import AnimatedText from "../components/AnimatedText";


const Landing = ({className, children})=>{
  const [showServices, setShowServices] = useState(false)
  const [isOpen, setIsOpen] = useState(false);
  const [signupLogin, setSignupLogin] = useState(false)
  const [isVisible, setIsVisible] = useState(false);
  const [isFadingOut, setIsFadingOut] = useState(false);
  const [isExpanded1, setIsExpanded1] = useState(false);
  const [isExpanded2, setIsExpanded2] = useState(false);
  const navigate = useNavigate()
  const [seeGallery, setSeeGallery] = useState(false)

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  const toHome = ()=>{
    navigate("/")
  }

  const toggleDiv = () => {
    if (showServices) {
      // Start fade-out animation
      setIsFadingOut(true);
      setTimeout(() => {
        setShowServices(false); // Remove element after fade-out
        setSignupLogin(false); // Remove element after fade-out
        setIsFadingOut(false);
      }, 500); // Adjust this to match the CSS transition duration
    } else {
      setShowServices(true);
    }
  }

    const toggleDrop = () => {
        setIsExpanded1(!isExpanded1);
    };
    const toggleDrop2 = () => {
        setIsExpanded2(!isExpanded2);
    };    

  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY;
      const viewHeight = window.innerHeight;

      if (scrollPosition > .01 * viewHeight) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    };
   
    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);
    
  const login = () =>{
      navigate("/login")
  }

  const signup = () => {
      navigate("/signup")
  }
  const onNavigate =()=>{setSeeGallery(true)}
  const onClose =()=>{setSeeGallery(false)}

  const toggleSignup = () =>{
    setSignupLogin(true)
  }
  
    return(
        <>
        <div className="relative">
        <nav className="border-b border-gray-200  relative">
                <div className="bg-indigo-500 flex p-3 items-center justify-between fixed top-0 left-0 w-full">
                    <div className="flex items-end cursor-pointer" onClick={toHome}>
                    <p className="font-indie lg:text-3xl text-white text-xl">Sunny Fresh</p>
                    <img src={logo} className="size-10" />
                    </div>

                    <div className="flex gap-2 font-semibold items-center">
                    <p className="font-saira text-white">Wash</p>
                    <img src={central} alt="IMAGES" className="size-10" />
                    <p className="font-saira text-white">Dryclean</p>
                    </div>

                    {/* Desktop Menu */}
                    <ul className="hidden lg:flex space-x-2">
                    <li className="p-1 border hover:bg-white text-white font-indie hover:text-blue-950 rounded">
                        <Link to="/about">About</Link>
                    </li>
                    <li className="p-1 border hover:bg-white text-white font-indie hover:text-blue-950 rounded">
                        <Link to="/contact">Contacts</Link>
                    </li>
                    
                    <li className="p-1 border hover:bg-white text-white font-indie hover:text-blue-950 rounded" onClick={toggleDiv}>
                        Services
                    </li>
                    </ul>

                    {/* Mobile Menu Button */}
                    <button className="lg:hidden p-2 text-gray-600" onClick={toggleMenu}>
                    {isOpen ? (
                        <FaBars className="hidden" size={24} />
                    ) : (
                        <FaBars size={24} />
                    )}
                    </button>
                </div>

                {/* Mobile Menu */}
                <div
                    className={`fixed z-30 top-0 left-0 h-full w-64 bg-white shadow-lg transform ${
                    isOpen ? "translate-x-0" : "-translate-x-full"
                    } transition-transform duration-300 ease-in-out`}
                >
                    <div className="flex justify-end p-4">
                    <button className="text-gray-600" onClick={toggleMenu}>
                        <FaTimes size={24} />
                    </button>
                    </div>
                    <ul className="flex flex-col space-y-2 p-4">
                    <li className="p-2 border hover:bg-gray-600 hover:text-white rounded">
                        <Link to="/" onClick={toggleMenu}>
                        Home
                        </Link>
                    </li>
                    <li className="p-2 border hover:bg-gray-600 hover:text-white rounded">
                        <Link to="/about" onClick={toggleMenu}>
                        About
                        </Link>
                    </li>
                    <li className="p-2 border hover:bg-gray-600 hover:text-white rounded">
                        <Link to="/contacts" onClick={toggleMenu}>
                        Contacts
                        </Link>
                    </li>
                    <li className="p-2 border hover:bg-gray-600 hover:text-white rounded">
                        <Link to="/products" onClick={toggleMenu}>
                        Shop
                        </Link>
                    </li>
                    <li className="p-2 border hover:bg-gray-600 hover:text-white rounded" onClick={toggleMenu}>
                        Services
                    </li>
                    </ul>
                </div>
                </nav>
        <div className="h-[100vh] w-full bg-cover bg-no-repeat bg-center mt-[60px] relative" style={{backgroundImage: "url('https://cdn.pixabay.com/photo/2020/02/06/02/08/laundromat-4822822_1280.jpg')"}} >            
        
        <AnimatedText/>
          {showServices && (
          <div className={`fixed z-40 top-10 container mx-auto px-4 py-5 left-10 bg-blue-950 rounded-lg opacity-90 bg-cover my-auto bg-no-repeat bg-center font-indie transition-opacity duration-500 ${isFadingOut ? "opacity-0" : "opacity-100"}`}>
            <h2 className="text-3xl font-bold text-white text-center mb-6">
                Our Services
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8">
                <div className="bg-white shadow-md rounded-lg hover:shadow-xl transition flex gap-2" onClick={toggleSignup} >
                  {/* <img src={image} className="object-cover w-[50%] h-full rounded-l-lg" alt="IMAGES" /> */}
                  <div className="w-[50% h-full p-6">
                      <h3 className="text-xl font-semibold text-gray-800 mb-2">Alterations and Repairs</h3>
                      <p className="text-gray-600">Tailoring services for garment adjustments, stitching, and minor repairs.</p>
                  </div>
                </div> 
                <div className="bg-white shadow-md rounded-lg hover:shadow-xl transition flex gap-2" onClick={toggleSignup} >
                  {/* <img src={image} className="object-cover w-[50%] h-full rounded-l-lg" alt="IMAGES" /> */}
                  <div className="w-[50% h-full p-6">
                      <h3 className="text-xl font-semibold text-gray-800 mb-2">Bedding and Linen Cleaning</h3>
                      <p className="text-gray-600">Comprehensive cleaning for bed sheets, duvet covers, pillowcases, and comforters.</p>
                  </div>
                </div> 
                <div className="bg-white shadow-md rounded-lg hover:shadow-xl transition flex gap-2" onClick={toggleSignup} >
                  {/* <img src={image} className="object-cover w-[50%] h-full rounded-l-lg" alt="IMAGES" /> */}
                  <div className="w-[50% h-full p-6">
                      <h3 className="text-xl font-semibold text-gray-800 mb-2">Curtain and Drapery Cleaning</h3>
                      <p className="text-gray-600">Detailed cleaning of your household drapes, curtains and carpets are available</p>
                  </div>
                </div> 
                <div className="bg-white shadow-md rounded-lg hover:shadow-xl transition flex gap-2" onClick={toggleSignup} >
                  {/* <img src={image} className="object-cover w-[50%] h-full rounded-l-lg" alt="IMAGES" /> */}
                  <div className="w-[50% h-full p-6">
                      <h3 className="text-xl font-semibold text-gray-800 mb-2">Dry Cleaning</h3>
                      <p className="text-gray-600">Premium dry-cleaning services for delicate garments.</p>
                  </div>
                </div> 
                <div className="bg-white shadow-md rounded-lg hover:shadow-xl transition flex gap-2" onClick={toggleSignup} >
                  {/* <img src={image} className="object-cover w-[50%] h-full rounded-l-lg" alt="IMAGES" /> */}
                  <div className="w-[50% h-full p-6">
                      <h3 className="text-xl font-semibold text-gray-800 mb-2">Ironing Services</h3>
                      <p className="text-gray-600">Professional ironing for a crisp and polished look.</p>
                  </div>
                </div> 
                <div className="bg-white shadow-md rounded-lg hover:shadow-xl transition flex gap-2" onClick={toggleSignup} >
                  {/* <img src={image} className="object-cover w-[50%] h-full rounded-l-lg" alt="IMAGES" /> */}
                  <div className="w-[50% h-full p-6">
                      <h3 className="text-xl font-semibold text-gray-800 mb-2">Laundry Services</h3>
                      <p className="text-gray-600">Efficient washing, drying, and folding for everyday clothes.</p>
                  </div>
                </div> 
                <div className="bg-white shadow-md rounded-lg hover:shadow-xl transition flex gap-2" onClick={toggleSignup} >
                  {/* <img src={image} className="object-cover w-[50%] h-full rounded-l-lg" alt="IMAGES" /> */}
                  <div className="w-[50% h-full p-6">
                      <h3 className="text-xl font-semibold text-gray-800 mb-2">Stain Removal</h3>
                      <p className="text-gray-600">Expert stain treatment for tough stains on any fabric.</p>
                  </div>
                </div> 
                <div className="bg-white shadow-md rounded-lg hover:shadow-xl transition flex gap-2" onClick={toggleSignup} >
                  {/* <img src={image} className="object-cover w-[50%] h-full rounded-l-lg" alt="IMAGES" /> */}
                  <div className="w-[50% h-full p-6">
                      <h3 className="text-xl font-semibold text-gray-800 mb-2">Leather and Suede Cleaning</h3>
                      <p className="text-gray-600">Specialised care for cleaning and restoring delicate leather and suede garments.</p>
                  </div>
                </div> 
                <div className="bg-white shadow-md rounded-lg hover:shadow-xl transition flex gap-2" onClick={toggleSignup} >
                  {/* <img src={image} className="object-cover w-[50%] h-full rounded-l-lg" alt="IMAGES" /> */}
                  <div className="w-[50% h-full p-6">
                      <h3 className="text-xl font-semibold text-gray-800 mb-2">Wedding Gown Preservation</h3>
                      <p className="text-gray-600">Special care for cleaning and preserving wedding gowns.</p>
                  </div>
                </div>
            </div>
            
          </div>
          )}
            {signupLogin && (
              <div className="fixed bottom-0 left-0 w-full bg-indigo-500 p-4 flex-col flex justify-center gap-4 text-white z-50">
                <p className="mx-auto font-semibold">Join our agile community to find and access exclusive deals and offers.</p>
                <div className=" mx-auto flex gap-4 w-[40%]">
                    <button onClick={signup} className="bg-black w-full  py-2 rounded">Sign me up</button>
                    <button onClick={login} className="bg-indigo-300 w-full py-2 rounded">Log in</button>
                </div>
            </div>
            )}
            </div>
        </div>
        </>
    );
}
export default Landing;