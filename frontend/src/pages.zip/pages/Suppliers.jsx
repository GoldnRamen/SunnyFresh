import React, { useState, useEffect, useRef } from "react";
import { Link, useNavigate } from "react-router-dom";

import logo from "../PNG/household.png"
import profile from "../PNG/wBwFnhsaRXyqZk-TcOvz3w.webp"
import { MdEmail, MdOutlineCategory, MdSpaceDashboard } from "react-icons/md";
import { HiMiniInboxArrowDown } from "react-icons/hi2";
import { AiFillSchedule } from "react-icons/ai";
import { IoIosPeople, IoMdNotifications } from "react-icons/io";
import { GiBiceps, GiSoap } from "react-icons/gi";
import { LiaStoreAltSolid } from "react-icons/lia";
import { FaClipboardList, FaPlus, FaTools } from "react-icons/fa";
import { SiBlockbench } from "react-icons/si";
import { RiFirstAidKitFill } from "react-icons/ri";
import { BsThreeDots } from "react-icons/bs";
import { BiPhone } from "react-icons/bi";
import axios from "axios";
import { toast, ToastContainer } from "react-toastify";

const Suppliers = () => {
  const loggedUser = JSON.parse(localStorage.getItem("laundry_admin"))
  const adminId = loggedUser.id
  const adminFname = loggedUser.firstName
  const adminLname = loggedUser.lastName
  const [supplierData, setSupplierData] = useState([]);
  const [seeOpns, setSeeOpns] = useState({});
  const [submissions, setSubmissions] = useState([]);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState({});
  const [editingSupplierId, setEditingSupplierId] = useState(null);
  const [supplierForm, setSupplierForm] = useState(false);
  const [updateData, setUpdateData] = useState(false)
  const [deleteData, setDeleteData] = useState(null)

  const [inputValues, setInputValues] = useState({
    firstName: "",
    lastName: "",
    username: "",
    email: "",
    phone: "",
    avatar: "",
    gender: "",
    password: "",
  });

  const navigate = useNavigate()
  const opnsRef = useRef(null);
  
  const toHome = ()=>{
    navigate("/")
  }
  
  const toggleSupplierForm = ()=>{
    setSupplierForm(true)
  }
  useEffect(()=>{
    const handleOutClick = (event) => {
      if (opnsRef.current && !opnsRef.current.contains(event.target)){
        setSeeOpns({})
      }
    };
    document.addEventListener("mousedown", handleOutClick)
    return()=>{
      document.removeEventListener("mousedown", handleOutClick)
    }
  },[])

  useEffect(() => {
    const handleAllSuppliers = async () => {
      try {
        if (!adminId) return; // Ensure adminId exists before making the request
  
        console.log("Admin ID:", adminId);
  
        const resp = await axios.get("http://localhost:5000/api/users/supplier/all");
        console.log(resp.data);
  
        setSupplierData(resp.data.data.filter(user => user.role === "supplier"))
  
        // Store token if available
        const token = resp.data.token;
        if (token) {
          localStorage.setItem("adminToken", token);
        }
  
        // Corrected status check
        if (resp.data.status !== 200) {
          console.log("Data not found");
        }
  
      } catch (error) {
        setError(error.message);
        console.error("Error fetching all employees:", error.response?.data || error.message);
        toast.error("Trouble loading details");
      }
    };
  
    handleAllSuppliers();
  }, [adminId]); // Runs whenever adminId changes

  const onClose =()=>{
    setUpdateData(false)
    setDeleteData(false)
    setSupplierForm(false)
    setEditingSupplierId(false)
    setSeeOpns(false)
  }

  const toggleOpns = (customerId) => {
    setSeeOpns((prev) => ({
      ...prev,
      [customerId]: !prev[customerId], // Toggle specific customer's options
    }));
  };

const validateEmail = () => {
return /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(inputValues.email);
};

const validatePassword = () => {
return /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,12}$/.test(inputValues.password);
};
const validatePhone = () => {
return /^\d{10,15}$/.test(inputValues.phone);
};
const validateAvatar = () => {
return /^(https?|ftp):\/\/[^\s/$.?#].[^\s]*$/.test(inputValues.avatar);
};


const formValidate = () => {
const newErrors = {};
if (inputValues.firstName.trim().length < 2) {
newErrors.firstName = "First name must be at least 2 characters long";
}
if (inputValues.lastName.trim().length < 2) {
newErrors.lastName = "Last name must be at least 2 characters long";
}
if (inputValues.username.trim().length < 2) {
newErrors.username = "Username must be at least 2 characters long";
}
if (inputValues.email.trim().length < 2) {
newErrors.username = "Email cannot be empty";
}
if (!inputValues.avatar) {
newErrors.avatar = "Image is required!";
}
if (!validateEmail()) {
newErrors.email = "Invalid email address";
}
if (!validatePhone()) {
newErrors.phone = "Invalid phone number";
}       
if (!validateAvatar()) {
newErrors.avatar = "Invalid Image format";
}       
if (!validatePassword()) {
newErrors.password =
    "Password must be 4-8 characters long, include at least one uppercase letter, one lowercase letter, and one number";
}
setError(newErrors);
return Object.keys(newErrors).length === 0;
};

const handleChange = (e) => {
const { value, name } = e.target;
setInputValues((prevState) => ({
...prevState,
[name]: value,
}));
};
const handleCreate = async (e) => {
  e.preventDefault();

  if (
    !inputValues.firstName ||
    !inputValues.lastName ||
    !inputValues.username ||
    !inputValues.email ||
    !inputValues.phone ||
    !inputValues.avatar ||
    !inputValues.gender ||
    !inputValues.password
  ) {
    toast.warn("All fields must be filled!!");
    alert("All fields must be entered");
    console.log("fields unsubmitted");
    return;
  }

  // Additional form validation and state update
  
    try {
      const resp = await axios.post(
        `http://localhost:5000/api/users/register/supplier`,
        inputValues
      );

      if (resp.data.success) {
        // Successfully updated customer data in the database
        toast.success("Supplier created successfully!");

        // Update the customerData state to reflect changes without reloading the page
        setSupplierData((prevState) => !prevState);
        setSupplierForm((prevState) => !prevState);

        // Clear the form fields after successful submission
        setInputValues({
          firstName: "",
          lastName: "",
          username: "",
          email: "",
          phone: "",
          avatar: "",
          gender: "",
          password: "",
        });
      } else {
        toast.error("Something went wrong while updating!");
        alert("Something went wrong");
      }
    } catch (error) {
      if (error.response) {
        console.error("Error:", error.response.status);
        if (error.response.status === 403) {
          toast.warn("You do not have permission to access this resource.");
        }
      } else {
        console.error("Error:", error.message);
        toast.error("An error occurred. Please try again.");
      }
    }
};
const handleSubmit = async (e, supplierId) => {
  e.preventDefault();

  if (
    !inputValues.firstName ||
    !inputValues.lastName ||
    !inputValues.phone ||
    !inputValues.avatar ||
    !inputValues.gender ||
    !inputValues.password
  ) {
    toast.warn("All fields must be filled!!");
    alert("All fields must be entered");
    console.log("fields unsubmitted");
    return;
  }

  // Additional form validation and state update
  
    try {
      const resp = await axios.put(
        `http://localhost:5000/api/users/supplier/edit/${supplierId}`,
        inputValues
      );

      if (resp.data.success) {
        // Successfully updated customer data in the database
        toast.success("Supplier details updated successfully!");

        // Update the customerData state to reflect changes without reloading the page
        setSupplierData((prevState) =>
          prevState.map((supplier) =>
            supplier._id === supplierId ? { ...supplier, ...inputValues } : supplier
          )
        );
        setEditingSupplierId(false)

        // Clear the form fields after successful submission
        setInputValues({
          firstName: "",
          lastName: "",
          phone: "",
          avatar: "",
          gender: "",
          password: "",
        });
      } else {
        toast.error("Something went wrong while updating!");
        alert("Something went wrong");
      }
    } catch (error) {
      if (error.response) {
        console.error("Error:", error.response.status);
        if (error.response.status === 403) {
          toast.warn("You do not have permission to access this resource.");
        }
      } else {
        console.error("Error:", error.message);
        toast.error("An error occurred. Please try again.");
      }
    }
  };
  const handleDelete = async(supplierId) =>{
    try {
      if (!supplierId) {
        toast.error("Invalid Supplier ID");
        return;
      }
      const response = await axios.delete( `http://localhost:5000/api/users/supplier/remove/${supplierId}`)
      if(response.data.success){
        toast.success("Supplier Deleted Successfully", {autoClose:2000})
        setDeleteData(false)
        setSeeOpns(false)
      }
      else{
        toast.error("Failed to delete Supplier", {autoClose:2000})
      }
    } catch (error) {
      console.error("Error:", error.message);
          toast.error("An error occurred. Please try again.", {autoClose:2000});
    }
  }

  return (
    <>
    <div className="bg-blue-200 w-full h-full z-50">
      
        
      <div className="mt-[8%]">
        
        <div className="mt-20">
        <div className="fixed left-0 w-[250px] top-2 p-1 border-r border rounded shadow-slate-700 shadow-lg h-fit bg-blue-800" >
            <div className="flex items-end mb-12 cursor-pointer" onClick={toHome}>
              <p className="font-indie lg:text-3xl text-white text-xl animate-pulse"><u>Sunny Fresh</u></p>
              <img src={logo} alt="logo-image" className="size-10" />
            </div>
            <div className="overflow-y-scroll scrollbar-thin scrollbar-track-transparent h-[80vh] scrollbar-thumb-blue-950 relative">
              <div className="">
                <Link to="/adminDash" className="no-underline text-white">
                  <p className="p-2 text-sm border-b-orange-800 cursor-pointer hover:shadow-black hover:shadow flex gap-1 items-center">
                  <MdSpaceDashboard className="text-white"/>Dashboard
                  </p>
                </Link>
                <Link to="/inbox" className="no-underline text-white">
                  <p className="p-2 text-sm border-b-orange-300 cursor-pointer hover:shadow-black hover:shadow flex gap-1 items-center">
                  <HiMiniInboxArrowDown className="text-white"/>Inbox
                  </p>
                </Link>
                <Link to="/allUsers" className="no-underline text-white">
                  <p className="p-2 text-sm border-b-orange-300 cursor-pointer hover:shadow-black hover:shadow flex gap-1 items-center">
                  <AiFillSchedule className="text-white"/>Schedule
                  </p>
                </Link>
              </div>
              <p className="p-3 text-sm font-bold text-gray-300 border-b-orange-300">
                  PERSONNEL
              </p>
              <div className="">
                 
                <Link to="/customers" className="no-underline text-white">
                  <p className="p-2 text-sm border-b-orange-300 cursor-pointer hover:shadow-black hover:shadow flex gap-1 items-center">
                  <IoIosPeople className="text-white"/>Customers
                  </p>
                </Link> 
                <Link to="/employees" className="no-underline text-white">
                  <p className="p-2 text-sm border-b-orange-300 cursor-pointer hover:shadow-black hover:shadow flex gap-1 items-center">
                  <GiBiceps className="text-white"/>Employees
                  </p>
                </Link>   
                <Link to="/suppliers" className="no-underline text-white">
                  <p className="p-2 text-sm border-b-2 border-b-black cursor-pointer text-blue-800 hover:shadow-black hover:shadow flex gap-1 items-center bg-white">
                  <LiaStoreAltSolid className="text-blue-800"/>Suppliers
                  </p>
                </Link> 
              </div>
              
              <Link to={"/inventory"} className="cursor-pointer">
                <p className="p-3 text-sm text-gray-300 border-b-orange-300 font-bold">
                    INVENTORY
                </p>
              </Link>
              <div>
                <Link to="/allUsers" className="no-underline text-white">
                  <p className="p-2 text-sm border-b-orange-300 cursor-pointer hover:shadow-black hover:shadow flex gap-1 items-center">
                  <FaTools className="text-white"/>Equipment
                  </p>
                </Link>
                <Link to="/allUsers" className="no-underline text-white">
                  <p className="p-2 text-sm border-b-orange-300 cursor-pointer hover:shadow-black hover:shadow flex gap-1 items-center">
                  <GiSoap className="text-white"/>Consumables
                  </p>
                </Link>
                <Link to="/allUsers" className="no-underline text-white">
                  <p className="p-2 text-sm border-b-orange-300 cursor-pointer hover:shadow-black hover:shadow flex gap-1 items-center">
                  <SiBlockbench className="text-white"/>Amenities
                  </p>
                </Link>
                <Link to="/allUsers" className="no-underline text-white">
                  <p className="p-2 text-sm border-b-orange-300 cursor-pointer hover:shadow-black hover:shadow flex gap-1 items-center">
                  <FaClipboardList className="text-white"/>Operational Supplies
                  </p>
                </Link>
                <Link to="/allUsers" className="no-underline text-white">
                  <p className="p-2 text-sm border-b-orange-300 cursor-pointer hover:shadow-black hover:shadow flex gap-1 items-center">
                  <RiFirstAidKitFill className="text-white"/>Safety & Maintenance
                  </p>
                </Link>
              </div>
              <Link to="/login" className="no-underline text-black">
                <p className="p-3 border-b cursor-pointer text-red-500 font-bold">
                    Logout
                </p>
              </Link>
              
            </div>
            
          </div>
          <div className="flex fixed flex-col w-full h-[10vh] bg-white z-50 top-0 left-[20%] mx-auto border shadow-slate-700 shadow-lg p-3">
            <div className="relative h-fit w-fit flex items-center m-2">
              <p className="font-indie font-bold">Suppliers</p>
              <div className="fixed flex items-center gap-3 right-5">
                <IoMdNotifications className="rounded-full border-2 p-2 size-10 text-black"/>
                <Link to="/" className="my-auto text-center">
                  <img src={profile} className="mx-auto my-auto border-2 rounded-full size-10" alt="IMAGES" />
                </Link>
                <p className="text-xs">{adminFname}&nbsp;{adminLname}</p>
              </div>
            </div>
          </div>
          <div className="mt-[10vh] ml-[20%]">
            <div className="flex justify-between p-1 relative">
              {supplierForm && (
                <div className="w-[80%] h-[85%] bg-black opacity-95 z-50 fixed top-20 right-5">
                  <p className="text-center mt-2 text-white">Supplier Registeration Form</p>
                  <form action="" onSubmit={handleCreate}>
                    <div className="w-full h-fit flex flex-col mx-auto mt-8 space-y-2">
                        <input type="text" onChange={handleChange} name="firstName" value={inputValues.firstName} className="bg-white w-[30%] h-[60%] p-2 mx-auto rounded-lg" placeholder="Firstname" />
                        <input type="text" onChange={handleChange} name="lastName" value={inputValues.lastName} className="w-[30%] h-[60%] p-2 mx-auto rounded-lg" placeholder="Lastname"/>
                        <input type="text" onChange={handleChange} name="username" value={inputValues.username} className="w-[30%] h-[60%] p-2 mx-auto rounded-lg" placeholder="Username"/>
                        <input type="text" onChange={(e) => setInputValues({ ...inputValues, email: e.target.value })} name="email" value={inputValues.email} className="w-[30%] h-[60%] p-2 mx-auto rounded-lg" placeholder="Email" />
                        <input type="text" onChange={(e) => setInputValues({ ...inputValues, avatar: e.target.value })} name="avatar" value={inputValues.avatar} className="w-[30%] h-[60%] p-2 mx-auto rounded-lg bg-white" placeholder="Avatar" />
                        <input type="text" onChange={(e) => setInputValues({ ...inputValues, phone: e.target.value })} name="phone" value={inputValues.phone} className="w-[30%] h-[60%] p-2 mx-auto rounded-lg bg-white" placeholder="Phone" />
                        <select name="gender" onChange={handleChange} value={inputValues.gender} className="w-[30%] h-[60%] p-2 mx-auto rounded-lg" id="">
                            <option value="">Gender</option>
                            <option value="male">Male</option>
                            <option value="female">Female</option>
                        </select>
                        <input type="password" onChange={(e) => setInputValues({ ...inputValues, password: e.target.value })} name="password" value={inputValues.password} className="w-[30%] h-[60%] p-2 mx-auto rounded-lg" placeholder="Password"/>
                        
                    </div>
                    
                    <div className="mx-auto mt-5 w-[30%] flex gap-5">
                        <button className="bg-yellow-600 text-white p-2 text-center rounded w-full">Submit</button>
                        <p onClick={onClose} className="text-white text-center flex p-3 border w-fit rounded cursor-pointer">Close</p>
                    </div>
                  </form>
                </div>
              )}
              {supplierData.length && (
                <p className="text-2xl font-semibold flex gap-1"><p className="text-green-950">{supplierData.length}</p> Supplier(s)</p>
              )}
              <div className="flex-col flex gap-1">
                <div className="p-2 text-center w-full items-center flex cursor-pointer h-fit rounded-lg bg-blue-800 text-white relative group">
                  <FaPlus className="text-white size-3" onClick={toggleSupplierForm}/>
                  <div className="absolute -bottom-[40%] right-7 transform -translate-y-1/2 translate-x-[-8px] px-1 py-1 bg-blue-900 text-white text-xs opacity-0 group-hover:opacity-100 transition-opacity w-fit">
                      Add&nbsp;Supplier
                  </div>
                </div>
                <div className="p-2 text-center w-full items-center flex cursor-pointer h-fit rounded-lg bg-blue-800 text-white relative group">
                  <MdOutlineCategory className="text-white size-3" />
                  <div className="absolute -bottom-[40%] right-7 transform -translate-y-1/2 translate-x-[-8px] px-1 py-1 bg-blue-900 text-white text-xs opacity-0 group-hover:opacity-100 transition-opacity">
                      Supply&nbsp;Store
                  </div>
                </div>
              </div>
            </div>
            <div className="gap-2 grid grid-cols-3 p-3"> {/* gap here is used till the api supplies the data */}
              {supplierData && supplierData.length > 0 ? (
                [...supplierData]
                .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)) // Sort by latest first
                .map((supplier) => (
                  <div className="bg-blue-800 flex flex-col shadow-md rounded-lg p-4 w-full mx-auto relative" key={supplier._id}>
                     {editingSupplierId === supplier._id && (
                        <div className="w-[80%] h-[85%] bg-black opacity-95 z-50 fixed top-20 right-5" ref={opnsRef}>
                          <div className="h-fit flex flex-col relative">
                          <p className="text-center mt-2 text-white">Supplier Update Form</p>
                          <form onSubmit={(e)=>handleSubmit(e, supplier._id)} className="space-y-4 mt-4">
                          <div className="w-full h-fit flex flex-col mx-auto mt-2 space-y-2">
                              <input type="text"
                                id="firstName"
                                name="firstName"
                                value={inputValues.firstName}
                                onChange={handleChange}
                                className="w-[30%] h-[60%] p-2 mx-auto rounded-lg"
                                placeholder="First Name"

                              />
                              <input
                                type="text"
                                id="lastName"
                                name="lastName"
                                value={inputValues.lastName}
                                onChange={handleChange}
                                className="w-[30%] h-[60%] p-2 mx-auto rounded-lg"
                                placeholder="Last Name"
                              />
                              <input
                                type="tel"
                                id="phone"
                                name="phone"
                                value={inputValues.phone}
                                onChange={handleChange}
                                className="w-[30%] h-[60%] p-2 mx-auto rounded-lg"
                                placeholder="Phone"
                              />
                              <input
                                type="text"
                                id="avatar"
                                name="avatar"
                                value={inputValues.avatar}
                                onChange={handleChange}
                                className="w-[30%] h-[60%] p-2 mx-auto rounded-lg"
                                placeholder="Avatar"
                              />
                              <select
                                id="gender"
                                name="gender"
                                value={inputValues.gender}
                                onChange={handleChange}
                                className="w-[30%] h-[60%] p-2 mx-auto rounded-lg"
                                placeholder=""
                              >
                                <option value="">Select Gender</option>
                                <option value="male">Male</option>
                                <option value="female">Female</option>
                                <option value="other">Other</option>
                              </select>
                              <input
                                type="password"
                                id="password"
                                name="password"
                                value={inputValues.password}
                                onChange={handleChange}
                                className="w-[30%] h-[60%] p-2 mx-auto rounded-lg"
                                placeholder="Password"
                              />

                              <div className="mx-auto mt-5 w-[30%] flex gap-5">
                                <button className="bg-yellow-600 text-white p-2 text-center rounded w-full">Submit</button>
                                <p onClick={onClose} className="text-white text-center flex p-3 border w-fit rounded cursor-pointer">Close</p>
                              </div>
                            </div>
                          </form>
                          </div>
                        </div>
                      )}
                      {deleteData === supplier._id && (
                        <div className="w-[80%] h-[100%] bg-black opacity-90 z-50 fixed right-0 top-20" ref={opnsRef}>
                          <div className="mt-[15vh] flex flex-col relative">
                            <p className="text-white text-center">Are you sure you want to delete this supplier's data? Action is <strong className="text-red-700">irreversible!!</strong></p>
                            <div className="flex gap-5 mx-auto mt-10 items-center">
                              <button onClick={()=>handleDelete(supplier._id)} className="bg-red-500 border-2 border-black hover:border-red-800 hover:text-red-950 hover:animate-pulse text-white font-semibold rounded-lg p-2 w-fit h-fit">Delete</button>
                              <button className="rounded-lg p-2 w-fit h-fit border mx-auto text-white" onClick={onClose}>Close</button>
                            </div>
                          </div>
                        </div>
                      )}
                  <div className="flex flex-col">
                    <div className="flex justify-between items-center">
                      <img src={supplier.avatar} className="size-20 border rounded-full border-white object-cover object-top" alt="IMAGES" />
                      <BsThreeDots className="text-white" onClick={()=> toggleOpns(supplier._id)}/>
                      {seeOpns[supplier._id] && (
                        <div className="flex flex-col rounded-lg bg-white absolute top-20 right-5" ref={opnsRef}>
                          <ul>
                            <li className="border-b p-2 cursor-pointer text-blue-900" onClick={() => setEditingSupplierId(supplier._id)}>Update Info</li>
                            <li className="text-red-700 p-2 cursor-pointer" onClick={()=>setDeleteData(supplier._id)}>Delete Info</li>
                          </ul>
                        </div>
                      )}
                    </div>
                    <div className="text-white">
                      <p className="text-sm font-bold">Name: {supplier.firstName} {supplier.lastName}</p>
                      <p className="text-sm">Username: {supplier.username}</p>
                      <p className="text-sm">Wash Supervisor</p>
                    </div>
                  </div>
                  <div className="p-2 mt-4 rounded-lg bg-blue-400 font-semibold">
                    <div className="flex justify-between items-center text-gray-600">
                      <p className="text-sm">Department</p>
                      <p className="text-sm">Hired Date</p>
                    </div>
                    <div className="flex justify-between items-center font-semibold">
                      <p className="text-sm">Wash</p>
                      <p className="text-sm">{supplier.createdAt.split("T")[0]}</p>
                    </div>
                    <div className="mt-4">
                      <p className="mb-2 font-semibold">Contact Info:</p>
                      <p className="flex items-center gap-3"><MdEmail />{supplier.email}</p>
                      <p className="flex items-center gap-3"><BiPhone />{supplier.phone}</p>
                    </div>
                  </div>
                  </div>  
              ))
              ) : (
              "No Suppliers Found"
              )} 
            </div>
          </div>
        </div>
      </div>
      </div>
      <ToastContainer/>
    </>
  );
};
export default Suppliers;
