// App.js
import React, { useState } from "react";
import logo from "../PNG/household.png"
import image from "../PNG/premium_photo-1663091838463-82ec12b917e8.avif";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { toast, ToastContainer } from "react-toastify";

const SupplierLogin = () => {
  // const [submission, setSubmission] = useState(null)
  // const [submitted, setSubmitted] = useState(false)

  // const toEmployeeDash = () =>{
  //   navigate("/supplierDash")
  // }
  // const toDash = () =>{
  //   navigate("/login")
  // }

  const [submissions, setSubmissions] = useState([])
  const navigate = useNavigate()
  
  const [inputValues, setInputValues] = useState({
    email: "",
    password: "",
  });
  const handleChange = (e) => {
    const { value, name } = e.target;
    setInputValues((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };
  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
        // Send the POST request with form data
        const resp = await axios.post(
            "http://localhost:5000/api/users/login/supplier",
            inputValues
        );
        const loggedUser = resp.data.data;
        // Check if the registration was successful
        if (loggedUser.role == "supplier") {
          // setSubmissions(prev => [...prev, inputValues]);
          setInputValues({
              email: "",
              password: "",
          });
          // setSubmitted(true);
          localStorage.setItem("laundry_supplier_loggedUser", JSON.stringify(loggedUser))
          toast.success("Credentials Accepted!");
          console.log(loggedUser);
          navigate("/supplierDash")
        }
        else if(loggedUser.role !== "supplier"){
          toast.warn("Invalid User Path")
          setInputValues({
            email: "",
            password: "",
        });
        }

        
        // if (formValidate()) {
        //     setSubmissions(prev => [...prev, inputValues]);
        //     setInputValues({
        //         email: "",
        //         password: "",
        //     });
        //     setSubmitted(true);
        //     alert("Form submitted successfully!");
        // }
    } catch (error) {
        if (error.response) {
            console.error("Error:", error.response.status);
            if (error.response.status === 403) {
                toast.warn("You do not have permission to access this resource.");
                setInputValues({
                  email: "",
                  password: "",
              });
            }
        } else {
            console.error("Error:", error.message);
            toast.error("An error occurred. Please try again.");
            setInputValues({
              email: "",
              password: "",
          });
        }
    }
};

  return (
    <>
    <div className="flex h-screen bg-gray-100">
      {/* Left Column with Image */}
      <div className="lg:block w-1/2 bg-blue-500 flex items-center justify-center">
        <img
          src={image}
          alt="Placeholder"
          className="w-full h-full object-cover object-top"
        />
      </div>

      {/* Right Column with Form */}
      <div className="mx-auto lg:w-1/2 flex flex-col items-center justify-center p-8 bg-gradient-to-b from-yellow-500 via-yellow-600 to-yellow-700">
        <div className="flex items-end m-3">
          <p className="font-indie lg:text-3xl text-black text-xl">Sunny Fresh</p>
          <img src={logo} alt="logo-image" className="size-10" />
        </div>
        <div className="w-full max-w-md bg-white p-6 rounded-lg shadow-lg border-2 border-yellow-950 relative">
          <h2 className="text-2xl text-center font-bold mb-4">
            <p className="font-saira underline text-yellow-900">Login</p>
          </h2>
          <form className="font-indie" onSubmit={handleSubmit}>
            <div className="mb-4">
              <label className="block text-gray-700">Email</label>
              <input
                type="email"
                className="w-full p-2 border border-gray-300 rounded"
                required
                name="email"
                placeholder="Type something..."
                value={inputValues.email}
                onChange={handleChange}
              />
            </div>
            <div className="mb-4">
              <label className="block text-gray-700">Password</label>
              <input
                type="password"
                className="w-full p-2 border border-gray-300 rounded"
                required
                name="password"
                placeholder="Type something..."
                value={inputValues.password}
                onChange={handleChange}
              />
            </div>
            <div className="flex items-center justify-between">
              <button
                type="submit"
                className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
                Login
              </button>
            </div>
          </form>
          <button 
            className="bg-yellow-500 text-white px-4 py-2 rounded hover:bg-yellow-900 absolute right-10 bottom-5 font-indie"
            // onClick={toDash}
          >Back
          </button>
        </div>
      </div>
      {/* {submission && ( 
          <div className="my-10 p-5 space-y-4 bg-blue-500 h-fit w-fit mx-auto">
            <h1>User Name: {submission.name}</h1>
            <h1>User Age: {submission.age}</h1>
            <h1>User Email: {submission.email}</h1>
            <h1>User Phone: {submission.address}</h1>
            <h1>User Phone: {submission.phone}</h1>
         </div>
        )} */}
      {submissions.map((submission, index) => (
          <div key={index} className="my-10 p-5 space-y-4 bg-blue-500 h-fit w-fit mx-auto">
            <h1>User Name: {submission.name}</h1>
            <h1>User Age: {submission.age}</h1>
            <h1>User Email: {submission.email}</h1>
            <h1>User Phone: {submission.address}</h1>
            <h1>User Phone: {submission.phone}</h1>
         </div>
        ))}
    </div>
    <ToastContainer/>
    </>
  );
};
export default SupplierLogin;
