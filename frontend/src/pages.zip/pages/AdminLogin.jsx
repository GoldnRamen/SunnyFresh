// App.js
import React, { useState } from "react";
import logo from "../PNG/household.png"
import image from "../PNG/ChE-mt3AQNacSntZ4kTcuA.webp";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { toast, ToastContainer } from "react-toastify";

const AdminLogin = () => {
  const [error, setError] = useState({});
  const [submissions, setSubmissions] = useState([])
  const [submitted, setSubmitted] = useState(false)
  // const [loggedUser, setLoggedUser] = useState(null)
  const navigate = useNavigate()

  const toDash = () =>{
    navigate("/login")
  }
  const [inputValues, setInputValues] = useState({
    email: "",
    password: "",
  });
const validateEmail = () => {
return /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(inputValues.email);
};

const validatePassword = () => {
return /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,12}$/.test(inputValues.password);
};

const formValidate = () => {
const newErrors = {};
if (inputValues.email.trim().length < 2) {
newErrors.username = "Email cannot be empty";
}
if (!validateEmail()) {
newErrors.email = "Invalid email address";
}
if (!validatePassword()) {
newErrors.password =
    "Password must be 4-8 characters long, include at least one uppercase letter, one lowercase letter, and one number";
}
setError(newErrors);
return Object.keys(newErrors).length === 0;
};

  const handleChange = (e) => {
    const { value, name } = e.target;
    setInputValues((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhZG1pbl9kYXRhIjp7ImlkIjoiNjc4YTQ4ODZjNmJjNjA3NjQ0ZDg5MzEwIiwidXNlcm5hbWUiOiJCYXJuYWNsZSIsImVtYWlsIjoiYmFybmV5c0B5YWhvby5jb20uY29tIiwicm9sZSI6ImFkbWluIn0sImlhdCI6MTczNzExNTc4MywiZXhwIjoxNzM3MTE5MzgzfQ.2MaBvC2BknYBuu6K_9FlZOldHMlRYoWhjkkiiPkveCU"

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (
        !inputValues.email ||
        !inputValues.password
    ) {
        alert("All fields must be filled!!");
        return;
    }

    try {
        // Send the POST request with form data
        const resp = await axios.post(
            "http://localhost:5000/api/users/login/admin",
            inputValues,
            {
              headers: { Authorization: `Bearer ${token}` },
            }
        );

        // Check if the registration was successful
        if (resp.data.success) {
            const loggedUser = resp.data.data;
            toast.success("Credentials Accepted!");
            // console.log(loggedUser);
            localStorage.setItem("laundry_admin", JSON.stringify(loggedUser));
            localStorage.setItem("authToken", token)
            // setLoggedUser(loggedUser); // Assuming this is a state setter
            navigate("/adminDash");
        }

        // Additional form validation and state update
        if (formValidate()) {
            setSubmissions(prev => [...prev, inputValues]);
            setInputValues({                
                email: "",
                password: "",
            });
            setSubmitted(true);
        }
    } catch (error) {
        if (error.response) {
            console.error("Error:", error.response.status);
            if (error.response.status === 403) {
                toast.warn("You do not have permission to access this resource.");
            }
        } else {
            console.error("Error:", error.message);
            toast.error("An error occurred. Please try again.");
        }
    }
};   

  return (
    <div className="flex h-screen bg-white">
      {/* Left Column with Image */}
      <div className="lg:block w-1/2 bg-blue-500 flex items-center justify-center">
        <img
          src={image}
          alt="Placeholder"
          className="w-full h-full object-cover"
        />
      </div>

      {/* Right Column with Form */}
      <div className="mx-auto lg:w-1/2 flex flex-col items-center justify-center p-8">
        <div className="flex items-end m-3">
          <p className="font-indie lg:text-3xl text-black text-xl">Sunny Fresh</p>
          <img src={logo} className="size-10" />
        </div>
        <div className="w-full max-w-md p-6 rounded-lg shadow-lg bg-gradient-to-r from-red-950 via-red-900 to-red-950 relative">
          <form className="text-white font-indie" onSubmit={handleSubmit}>
            <div className="mb-4">
              <label className="block">Email</label>
              <input
                type="email"
                className="w-full p-2 border text-black border-gray-300 rounded"
                required
                name="email"
                placeholder="Type something..."
                value={inputValues.email}
                onChange={handleChange}
              />
            </div>
            <div className="mb-4">
              <label className="block">Password</label>
              <input
                type="password"
                className="w-full p-2 border text-black border-gray-300 rounded"
                required
                name="password"
                placeholder="Type something..."
                value={inputValues.password}
                onChange={handleChange}
              />
            </div>
            <div className="flex items-center justify-between">
              <button type="submit" className="bg-blue-800 text-white px-4 py-2 rounded hover:bg-blue-600">
                Submit
              </button>
              <p className="bg-white text-black px-4 py-2 rounded hover:bg-red-900 hover:text-white border border-black font-indie" onClick={toDash}>
                Back
              </p>
              
            </div>
          </form>
        </div>
      </div>      
      <ToastContainer/>
    </div>
  );
};
export default AdminLogin;
