import { Link, useNavigate } from "react-router-dom";
import bgImg from "../PNG/feet-1868670_1920.jpg"
import { FcGoogle } from "react-icons/fc";
import { useContext, useState } from "react";
import axios from "axios";
import { DataContext } from "../context/DataContext";

import logo from "../PNG/household.png"
import { toast, ToastContainer } from "react-toastify";

const Signup = ()=>{
    // const [error, setError] = useState({});
    const [submissions, setSubmissions] = useState([]);
    const [submitted, setSubmitted] = useState(false);
    const {loggedUser, setLoggedUser} = useContext(DataContext)
    const navigate = useNavigate();

    const toHome = () =>{
        navigate("/")
    }

    const [inputValues, setInputValues] = useState({
            firstName: "",
            lastName: "",
            username: "",
            email: "",
            phone: "",
            avatar: "",
            gender: "",
            password: "",
    });
    // const validateEmail = () => {
    //     return /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(inputValues.email);
    // };
    // const validatePassword = () => {
    //     return /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,12}$/.test(inputValues.password);
    // };
    // const validatePhone = () => {
    //     return /^\d{10,15}$/.test(inputValues.phone);
    // };
    // const validateAvatar = () => {
    //     return /^(https?|ftp):\/\/[^\s/$.?#].[^\s]*$/.test(inputValues.avatar);
    // };
   

    // const formValidate = () => {
    //     const newErrors = {};
    //     if (inputValues.firstName.trim().length < 2) {
    //     newErrors.firstName = "First name must be at least 2 characters long";
    //     }
    //     if (inputValues.lastName.trim().length < 2) {
    //     newErrors.lastName = "Last name must be at least 2 characters long";
    //     }
    //     if (inputValues.username.trim().length < 2) {
    //     newErrors.username = "Username must be at least 2 characters long";
    //     }
    //     if (inputValues.email.trim().length < 2) {
    //     newErrors.username = "Email cannot be empty";
    //     }
    //     if (!inputValues.avatar) {
    //     newErrors.avatar = "Image is required!";
    //     }
    //     if (!validateEmail()) {
    //     newErrors.email = "Invalid email address";
    //     }
    //     if (!validatePhone()) {
    //     newErrors.phone = "Invalid phone number";
    //     }       
    //     if (!validateAvatar()) {
    //     newErrors.avatar = "Invalid Image format";
    //     }       
    //     if (!validatePassword()) {
    //     newErrors.password =
    //         "Password must be 4-8 characters long, include at least one uppercase letter, one lowercase letter, and one number";
    //     }
    //     setError(newErrors);
    //     return Object.keys(newErrors).length === 0;
    // };

    const handleChange = (e) => {
        const { value, name } = e.target;
        setInputValues((prevState) => ({
        ...prevState,
        [name]: value,
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
    
        if (
            !inputValues.firstName ||
            !inputValues.lastName ||
            !inputValues.username ||
            !inputValues.email ||
            !inputValues.phone ||
            !inputValues.avatar ||
            !inputValues.gender ||
            !inputValues.password
        ) {
            toast.warn("All fields must be filled!!");
            return;
        }
    
            // Additional form validation and state update
        
            try {
                // Send the POST request with form data
                const resp = await axios.post(
                    "http://localhost:5000/api/users/register",
                    inputValues
                );
        
                // Check if the registration was successful
                if (resp.data.success) {
                    const loggedUser = resp.data.data;
                    toast.success("Registration Successful!");
                    console.log(loggedUser);
                    localStorage.setItem("laundry_customer", JSON.stringify(loggedUser));
                    setLoggedUser(loggedUser); // Assuming this is a state setter
                    navigate("/login");
                }
                setSubmissions(prev => [...prev, inputValues]);
                setInputValues({
                    firstName: "",
                    lastName: "",
                    username: "",
                    email: "",
                    phone: "",
                    avatar: "",
                    gender: "",
                    password: "",
                });
                setSubmitted(true);
            }
            catch (error) {
                if (error.response) {
                    console.error("Error:", error.response.status);
                    if (error.response.status === 403) {
                        toast.warn("You do not have permission to access this resource.");
                    }
                } else {
                    console.error("Error:", error.message);
                    toast.error("An error occurred. Please try again.");
                }
            }
        
        
    };          
    
    return(
        <>
            <div className="">
                <div className="">
                    <div className="relative h-[120vh] w-full bg-cover bg-no-repeat bg-top" style={{backgroundImage: `url('${bgImg}')`}}>
                        <div className="py-2 px-4 flex flex-col h-full w-full bg-zinc-900 opacity-80 font-indie">
                            <div className="flex flex-row justify-end font-bold">
                               <Link to={"/login"} className="no-underline text-black">
                                    <div className="">
                                        <button className="text-black bg-green-400 px-3 py-1 rounded font-indie">Login</button>
                                    </div>
                               </Link>
                            </div>
                            <div className="flex justify-center mb-12 cursor-pointer" onClick={toHome}>
                                <p className="font-indie lg:text-3xl text-white text-xl animate-pulse"><u>Sunny Fresh</u></p>
                                <img src={logo} alt="logo" className="size-10" />
                            </div>
                            <form action="" onSubmit={handleSubmit}>
                                <div className="w-full h-fit flex flex-col mx-auto mt-8 space-y-2">
                                    <input type="text" onChange={handleChange} name="firstName" value={inputValues.firstName} className="bg-white w-[30%] h-[60%] p-2 mx-auto rounded-lg" placeholder="Firstname" />
                                    <input type="text" onChange={handleChange} name="lastName" value={inputValues.lastName} className="w-[30%] h-[60%] p-2 mx-auto rounded-lg" placeholder="Lastname"/>
                                    <input type="text" onChange={handleChange} name="username" value={inputValues.username} className="w-[30%] h-[60%] p-2 mx-auto rounded-lg" placeholder="Username"/>
                                    <input type="text" onChange={(e) => setInputValues({ ...inputValues, email: e.target.value })} name="email" value={inputValues.email} className="w-[30%] h-[60%] p-2 mx-auto rounded-lg" placeholder="Email" />
                                    <input type="text" onChange={(e) => setInputValues({ ...inputValues, avatar: e.target.value })} name="avatar" value={inputValues.avatar} className="w-[30%] h-[60%] p-2 mx-auto rounded-lg bg-white" placeholder="Avatar" />
                                    <input type="text" onChange={(e) => setInputValues({ ...inputValues, phone: e.target.value })} name="phone" value={inputValues.phone} className="w-[30%] h-[60%] p-2 mx-auto rounded-lg bg-white" placeholder="Phone" />
                                    <select name="gender" onChange={handleChange} value={inputValues.gender} className="w-[30%] h-[60%] p-2 mx-auto rounded-lg" id="">
                                        <option value="">Gender</option>
                                        <option value="male">Male</option>
                                        <option value="female">Female</option>
                                    </select>
                                    <input type="password" onChange={(e) => setInputValues({ ...inputValues, password: e.target.value })} name="password" value={inputValues.password} className="w-[30%] h-[60%] p-2 mx-auto rounded-lg" placeholder="Password"/>
                                    
                                </div>
                                
                                <div className="mx-auto mt-5 w-[30%]">
                                    <button className="bg-yellow-600 text-white p-2 text-center rounded w-full">Sign up</button>
                                    <p className="text-white text-center flex p-2"></p>
                                </div>
                            </form>
                            <div className="w-full h-fit flex flex-col space-y-2">
                                <p className="mx-auto w-[30%] h-[60%] rounded flex justify-center p-3 bg-white items-center"><FcGoogle className="mr-5" />Continue with Google</p>
                            </div>
                        </div>
                        <div className="fixed bottom-20 left-10 items-center font-indie text-white space-x-3">
                            <ul className="flex space-x-2">
                                <li className="cursor-pointer">Terms</li>
                                <li className="cursor-pointer">Privacy</li>
                                <li className="cursor-pointer">Jobs</li>
                                <li className="cursor-pointer">Support</li>
                            </ul>
                        </div>
                        <div className="fixed bottom-20 flex right-10 text-white space-x-2 font-indie">
                            <p>Posted by The Bald Baron</p>
                            <img className="rounded-full object-cover object-center size-5 items-center flex" src='https://ideogram.ai/assets/progressive-image/balanced/response/q0DBy_u3Q3KdBbIV3jgI3Q' alt="IMAGES" />
                        </div>
                    </div>
                    
                </div>
            </div>
            <ToastContainer />
        </>
    )
}
export default Signup;