// App.js
import React, { useState } from "react";
import logo from "../PNG/household.png"
import image from "../PNG/2Ew7PvNYRceRcZ-aXf4LTA.webp";
import { Navigate, useNavigate } from "react-router-dom";
import axios from "axios";
import { toast, ToastContainer } from "react-toastify";

const EmployeeLogin = () => {
  const [isRegistering, setIsRegistering] = useState(false);
  // const [submission, setSubmission] = useState(null)
  const [submissions, setSubmissions] = useState([])
  const [submitted, setSubmitted] = useState(false)
  const navigate = useNavigate()

  const toDash = () =>{
    navigate("/login")
  }
  const toEmployeeDash = () =>{
    navigate("/employeeDash")
  }
  const toggleForm = () => {
    setIsRegistering(!isRegistering);
  };
  const [inputValues, setInputValues] = useState({
    email: "",
    password: "",
  });
  const handleChange = (e) => {
    const { value, name } = e.target;
    setInputValues((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };
  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
        // Send the POST request with form data
        const resp = await axios.post(
            "http://localhost:5000/api/users/login/employee",
            inputValues
        );

        // Check if the registration was successful
        const loggedUser = resp.data.data;
        // Check if the registration was successful
        if (loggedUser.role == "employee") {
          setSubmissions(prev => [...prev, inputValues]);
          setInputValues({
              email: "",
              password: "",
          });
          setSubmitted(true);
          localStorage.setItem("laundry_employee_loggedUser", JSON.stringify(loggedUser))
          toast.success("Credentials Accepted!");
          console.log(loggedUser);
          navigate("/employeeDash")
        }
        else if(loggedUser.role !== "employee"){
          toast.warn("Invalid User Path")
          setInputValues({
            email: "",
            password: "",
        });
        }
        
    } catch (error) {
        if (error.response) {
            console.error("Error:", error.response.status);
            if (error.response.status === 403) {
                toast.warn("You do not have permission to access this resource.");
                setInputValues({
                  email: "",
                  password: "",
              });
            }
        } else {
            console.error("Error:", error.message);
            toast.error("An error occurred. Please try again.");
            setInputValues({
              email: "",
              password: "",
          });
        }
    }
}; 

  return (
    <>
    <div className="flex h-screen bg-gray-100">
      {/* Left Column with Image */}
      <div className="lg:block w-1/2 bg-blue-500 flex items-center justify-center">
        <img
          src={image}
          alt="Placeholder"
          className="w-full h-full object-cover"
        />
      </div>

      {/* Right Column with Form */}
      <div className="mx-auto lg:w-1/2 flex flex-col items-center justify-center p-8 bg-gradient-to-b from-blue-300 via-blue-400 to-blue-500">
        <div className="flex items-end m-3">
          <p className="font-indie lg:text-3xl text-black text-xl">Sunny Fresh</p>
          <img src={logo} className="size-10" />
        </div>
        <div className="w-full max-w-md bg-white p-6 rounded-lg shadow-lg border-2 border-blue-950 relative">
          <h2 className="text-2xl text-center font-bold mb-4">
            <p className="font-saira text-blue-900 underline">Login</p>
          </h2>
          <form className="font-indie" onSubmit={handleSubmit}>
            <div className="mb-4">
              <label className="block text-gray-700">Email</label>
              <input
                type="email"
                className="w-full p-2 border border-gray-300 rounded"
                required
                name="email"
                placeholder="Type something..."
                value={inputValues.email}
                onChange={handleChange}
              />
            </div>
            <div className="mb-4">
              <label className="block text-gray-700">Password</label>
              <input
                type="password"
                className="w-full p-2 border border-gray-300 rounded"
                required
                name="password"
                placeholder="Type something..."
                value={inputValues.password}
                onChange={handleChange}
              />
            </div>
            <div className="flex items-center justify-between">
              <button
                type="submit"
                className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">Submit
              </button>
            </div>
          </form>
          <button 
            className="bg-white text-black px-4 py-2 rounded hover:bg-blue-900 hover:text-white absolute right-10 bottom-5 border border-blue-900 font-indie"
            onClick={toDash}
          >Back
          </button>
        </div>
      </div>
    </div>
    <ToastContainer/>
    </>
  );
};
export default EmployeeLogin;
