import { Link, useNavigate } from "react-router-dom";
import { useContext, useState } from "react";
import { DataContext } from "../context/DataContext";
import axios from "axios";

import employee from "../PNG/2Ew7PvNYRceRcZ-aXf4LTA.webp"
import admin from "../PNG/ChE-mt3AQNacSntZ4kTcuA.webp"
import supplier from "../PNG/premium_photo-1663091838463-82ec12b917e8.avif"
import logo from "../PNG/household.png"
import { toast, ToastContainer } from "react-toastify";

const Login = ()=>{
    // const [submissions, setSubmissions] = useState([]);
    
    const [submitted, setSubmitted] = useState(false);
    const [error, setError] = useState({});
    const [seeGallery, setSeeGallery] = useState(false)
    const {setLoggedUser, loggedUser} = useContext(DataContext)
    const navigate = useNavigate();
    const onNavigate =()=>{setSeeGallery(true)}
    const onClose =()=>{setSeeGallery(false)}
    const [inputValues, setInputValues] = useState({
            email: "",
            password: "",
    });

    const validatePassword = () => {
        return /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{4,8}$/.test(inputValues.password);
    };
    const validateEmail = () => {
        return /\S+@\S+\.\S+/.test(inputValues.email);
    };
    const toHome = ()=>{
        navigate("/")
    }
    const formValidate = () => {
        const newErrors = {};
        if (!validateEmail()) {
            newErrors.email = "Invalid email address";
            toast.warn("Invalid email address")
        }
        if (!validatePassword()) {
            newErrors.password = "Password must be 4-8 characters long, include at least one uppercase letter, one lowercase letter, and one number";
            toast.warn("Password must be 4-8 characters long, include at least one uppercase letter, one lowercase letter, and one number")
        }
        setError(newErrors);
        return Object.keys(newErrors).length === 0;
    };


    const handleChange = (e) => {
        const { value, name } = e.target;
        setInputValues((prevState) => ({
        ...prevState,
        [name]: value,
        }));
    };

    const handleSubmit = async (e) => {
    
        try {
          e.preventDefault();
          if (!inputValues.email || !inputValues.password) {
            toast.warn("All fields must be filled!!");
            return;
          }
          if (formValidate){
            const response = await axios.post("http://localhost:5000/api/users/login", inputValues);
            setSubmitted(true);
            if(response.status === 200 && response.data.data.role === "customer"){
                console.log("Welcome back User:", response.data);
                toast.success("Credentials Accepted!")
                const loggedUser = response.data.data;
                localStorage.setItem("laundry_customer_loggedUser", JSON.stringify(loggedUser))
                setLoggedUser(loggedUser)
                localStorage.setItem("Logged_customer_token", response.data.token)
                navigate("/services")
            }
            else if(response.status === 200 && response.data.role !== "customer"){
                console.log("Incorrect Login Route")
                toast.error("Invalid Path Route")
            }
          }
          
        } catch (error) {
          if (error.response) {
            console.error("Error:", error.response.status);
            if (error.response.status === 403) {
              toast.warn("You do not have permission to access this resource.");
            }
            else{
              toast.error("Login Failed: Email or Password is incorrect")
            }
        }
      }
    }
    
    return(
        <>
            <div>
                <div className="font-indie">
                    <div className="relative">
                    {seeGallery && (
                        <div className="fixed w-full h-[100vh] z-10 bg-black opacity-90 p-6 rounded shadow-lg text-center">
                        <div className="mt-[40vh] flex flex-col">
                            <div className="flex flex-row gap-4 mx-auto items-center px-10">
                                <Link to={"/adminLogin"}>
                                    <div className="flex flex-col rounded-full cursor-pointer border hover:bg-white py-6 px-7">
                                        <img src={admin} alt="admin" className="size-20 rounded-full text-white mx-auto"/>
                                        <p className="text-white hover:text-blue-950">Administrator</p>
                                    </div>
                                </Link>
                                <Link to={"/employeeLogin"}>
                                    <div className="flex flex-col rounded-full cursor-pointer border hover:bg-white py-6 px-9">
                                        <img src={employee} alt="employee" className="size-20 rounded-full text-orange-700 mx-auto"/>
                                        <p className="text-white hover:text-blue-950">Employee</p>
                                    </div>
                                </Link>
                                <Link to={"/supplierLogin"}>
                                    <div className="flex flex-col rounded-full cursor-pointer border hover:bg-white py-6 px-9">
                                        <img src={supplier} alt="supllier" className="size-20 rounded-full object-cover object-top  text-yellow-600 mx-auto"/>
                                        <p className="text-white hover:text-blue-950">Supplier</p>
                                    </div>
                                </Link>
                            </div>
                            <button className="p-3 border w-fit mx-auto rounded-3xl mt-5 text-white" onClick={onClose}>Close</button>
                        </div>
                    </div>
                    )}
                    </div>
                    <div className="h-[100vh] w-full bg-cover bg-no-repeat bg-center relative" style={{backgroundImage: "url('https://images.unsplash.com/photo-1521656543453-e4cac36c0c40?q=80&w=1374&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D')"}} >
                        <div className="py-2 px-4 flex flex-col h-full w-full bg-black opacity-70">
                            <div className="flex flex-row justify-between">
                                <div className="flex items-end">
                                    <p className="font-indie lg:text-3xl text-white text-xl" onClick={toHome}>Sunny Fresh</p>
                                    <img src={logo} alt="logo" className="size-10" />
                                </div>
                                <Link to={"/signup"}  className="no-underline text-black cursor-pointer">
                                    <div className="">
                                        <button className="text-black bg-blue-400 px-3 py-1 rounded font-bold">Sign up</button>
                                    </div>
                                </Link>
                            </div>
                            <form action="" onSubmit={handleSubmit}>
                                <div className="w-full h-fit flex flex-col mx-auto mt-24 space-y-2 opacity-100">
                                    <input type="text" className="bg-white w-[30%] p-2 h-[60%] mx-auto rounded-lg" name="email" value={inputValues.email} onChange={handleChange}  placeholder="Email" />
                                    <input type="password" className="w-[30%] h-[60%] p-2 mx-auto rounded-lg" name="password" value={inputValues.password} onChange={handleChange} placeholder="Password"/>
                                </div>
                                <div className="mx-auto my-5 w-[30%] text-center">
                                    <p className="text-xs text-white">By clicking log in, or continuing with the other options below, you agree to Tumblr’s Terms of Service and have read the Privacy Policy</p>
                                </div>
                                <div className="mx-auto w-[30%]">
                                    <button className="bg-blue-400 p-2 w-full text-center rounded">Login</button>
                                    <p className="text-white text-center p-2">Forgot your password?</p>
                                </div>
                            </form>
                            <div className="w-full h-fit flex flex-col space-y-2">
                                <p className="mx-auto w-[30%] h-[60%] rounded p-2 flex flex-row justify-center bg-white cursor-pointer" onClick={onNavigate}>Login to Dashboard</p>
                                <Link to="/signup"><p className="text-white text-center p-2">First time here? <u className="hover:text-blue-700">Sign up now!</u></p></Link>
                                {/* <p className="text-white text-center p-2 hover:underline">Register as Admin</p> */}
                            </div>
                            
                            <div className="flex items-center space-x-3 text-white absolute bottom-10 left-10">
                                <ul className="flex space-x-2">
                                    <li className="cursor-pointer">Terms</li>
                                    <li className="cursor-pointer">Privacy</li>
                                    <li className="cursor-pointer">Jobs</li>
                                    <li className="cursor-pointer">Support</li>
                                </ul>
                            </div>
                            <div className="flex text-white space-x-2 animate-pulse absolute bottom-10 right-10">
                                <p>See our latest offers</p>
                                <img className="rounded-full object-cover object-center size-5 items-center flex" src='https://ideogram.ai/assets/progressive-image/balanced/response/q0DBy_u3Q3KdBbIV3jgI3Q' alt="IMAGES" />
                            </div>
                        
                        </div>
                    </div>
                </div>
            </div>
            <ToastContainer />
        </>
    )
}
export default Login;